docker build -t ott .
docker run -it --rm -p 5000:5000 --name ott ott