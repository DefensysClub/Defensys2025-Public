Vegeta: Kakarot, you won’t believe this, but Beerus... he just retired from being a lord of destruction, now he’s taken up a new hobby, hacking and cybersecurity... He now goes by the name `BeerusTheExploiter1`. But that’s not all. He’s hidden something in his GitHub repo, and I need your help to crack it.

Goku: Wait, Beerus is into... hacking? What’s a GitHub repo?

Vegeta: Never mind that. The important thing is, Beerus has created a challenge to test our wits. He’s encrypted his secrets and placed them in his repository `Hakai9000` . 

Goku: Hmm... this sounds like a lot of work. Can we just punch something?

Vegeta: Ugh, Kakarot you fool! Go ahead and find a way to access his repository, you'll find the key somewhere.
